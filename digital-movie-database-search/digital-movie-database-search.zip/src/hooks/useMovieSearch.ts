import { useState, useCallback, useRef } from "react";
import { searchMovies, type MovieResult, MovieApiError } from "../services/movieApi";

interface UseMovieSearchReturn {
  results: MovieResult[];
  isLoading: boolean;
  error: string | null;
  hasSearched: boolean;
  search: (query: string) => Promise<void>;
  clearResults: () => void;
}

export function useMovieSearch(): UseMovieSearchReturn {
  const [results, setResults] = useState<MovieResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const search = useCallback(async (query: string) => {
    // Cancel any in-flight request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();

    setIsLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const movieResults = await searchMovies(query);
      setResults(movieResults);
    } catch (err) {
      if (err instanceof MovieApiError) {
        setError(err.message);
      } else {
        setError("An unexpected error occurred. Please try again.");
      }
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    setResults([]);
    setError(null);
    setHasSearched(false);
  }, []);

  return { results, isLoading, error, hasSearched, search, clearResults };
}
