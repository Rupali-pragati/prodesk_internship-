/**
 * Sanitize user input against XSS injection.
 * Strips HTML tags and encodes dangerous characters.
 */
export function sanitizeInput(input: string): string {
  const div = document.createElement("div");
  div.appendChild(document.createTextNode(input));
  return div.innerHTML;
}
