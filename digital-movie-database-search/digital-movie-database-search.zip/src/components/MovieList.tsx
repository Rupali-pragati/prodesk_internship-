import type { MovieResult } from "../services/movieApi";
import { MovieCard } from "./MovieCard";

interface MovieListProps {
  results: MovieResult[];
  query: string;
}

export function MovieList({ results, query }: MovieListProps) {
  return (
    <section aria-label="Search results">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-sm font-medium text-neutral-600">
          <span className="text-neutral-900">{results.length}</span>{" "}
          {results.length === 1 ? "result" : "results"} for{" "}
          <span className="font-semibold text-neutral-900">"{query}"</span>
        </h2>
      </div>
      <div
        className="grid gap-4 sm:grid-cols-1 lg:grid-cols-2"
        role="list"
        aria-label="Movie results list"
      >
        {results.map((movie) => (
          <div key={movie.id} role="listitem">
            <MovieCard movie={movie} />
          </div>
        ))}
      </div>
    </section>
  );
}
